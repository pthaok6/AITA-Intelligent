def main(:
    print("broken")

main()
