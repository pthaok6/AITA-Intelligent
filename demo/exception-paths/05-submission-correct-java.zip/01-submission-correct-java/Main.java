import java.util.Scanner;

/**
 * Bài toán: Tính tổng hai số nguyên a và b từ luồng dữ liệu chuẩn (System.in).
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        if (scanner.hasNextLong()) {
            long a = scanner.nextLong();
            long b = scanner.nextLong();
            System.out.println(a + b);
        }
    }
}
